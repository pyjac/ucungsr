package marf.nlp.Collocations;


/**
 * <p>TODO: implement.</p>
 * 
 * $Id: CollocationWindow.java,v 1.6 2006/01/06 22:20:13 mokhov Exp $
 * 
 * @author Serguei Mokhov
 * @version $Revision: 1.6 $
 * @since 0.3.0.2
 */
public class CollocationWindow
{
	/**
	 * Returns source code revision information.
	 * @return revision string
	 */
	public static String getMARFSourceCodeRevision()
	{
		return "$Revision: 1.6 $";
	}
}

// EOF
