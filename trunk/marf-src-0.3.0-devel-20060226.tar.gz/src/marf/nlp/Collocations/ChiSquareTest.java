package marf.nlp.Collocations;


/**
 * <p>TODO: implement.</p>
 * 
 * $Id: ChiSquareTest.java,v 1.7 2006/01/06 22:20:13 mokhov Exp $
 * 
 * @author Serguei Mokhov
 * @version $Revision: 1.7 $
 * @since 0.3.0.2
 */
public class ChiSquareTest
{
	/**
	 * Returns source code revision information.
	 * @return revision string
	 */
	public static String getMARFSourceCodeRevision()
	{
		return "$Revision: 1.7 $";
	}
}

// EOF
