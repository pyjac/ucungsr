package marf.nlp.Parsing;

import marf.util.NotImplementedException;


/**
 * <p>Code Generator. Not Implemented.
 * TODO: implement.
 * </p>
 *
 * $Id: CodeGenerator.java,v 1.8 2005/12/30 18:36:54 mokhov Exp $
 *
 * @author Serguei Mokhov
 * @version $Revision: 1.8 $
 * @since 0.3.0.2
 */
public class CodeGenerator
{
	/**
	 * Double-Word size in bytes.
	 */
	public static final int DW_SIZE = 2;
	
	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public CodeGenerator()
	{
		throw new NotImplementedException();
	}
	
	/**
	 * Not implemented.
	 * @throws NotImplementedException
	 */
	public static void genFunction()
	{
		throw new NotImplementedException();
	}
	
	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genWhile()
	{
		throw new NotImplementedException();
	}
	
	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genVar()
	{
		throw new NotImplementedException();
	}
	
	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genWrite()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genRead()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genAnd()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genOr()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genNot()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genAdd()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genSubs()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genDivide()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genMultiply()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genReturn()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genMain()
	{
		throw new NotImplementedException();
	}

	/**
	 * Default constructor.
	 * @throws NotImplementedException
	 */
	public static void genClass()
	{
		throw new NotImplementedException();
	}

	/**
	 * Returns source code revision information.
	 * @return revision string
	 */
	public static String getMARFSourceCodeRevision()
	{
		return "$Revision: 1.8 $";
	}
}

// EOF
